﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;


namespace KNNWithPCA
{
    class Program
    {
        static void Main(string[] args)
        {

                double[,] trainData = new double[2300,57];
                string fileName = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"data\iris.txt");
                const Int32 BufferSize = 128;
                using (var fileStream = File.OpenRead(fileName))
                using (var streamReader = new StreamReader(fileStream, Encoding.UTF8, true, BufferSize))
                {
                    String line;
                    int lineIndex = 0;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        string[] splitLine = line.Split(',');
                        double[] lineData = new double[splitLine.Length + 2];
                        double[] classData = new double[1];

                    }
                }
            PrincipalComponentAnalysis pcaAnalysis= new PrincipalComponentAnalysis(trainData);
            PrincipalComponent pca = new PrincipalComponent(trainData, 5);
           
            pca.Compute();
           double computeMatrix[,] = pca.ComponentMatrix;
           KNNs knn = new KNNs();
            result = knn.EuclideanDistance(computeMatrix);

        }
    }
}
